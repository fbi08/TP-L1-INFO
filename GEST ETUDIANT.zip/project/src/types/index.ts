// Type definitions for the student management system

export type Student = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  studentId: string;
  enrollmentDate: string;
  department: string;
  level: 'Undergraduate' | 'Graduate' | 'PhD';
  gpa: number;
  profileImage?: string;
  address?: string;
  phoneNumber?: string;
};

export type Course = {
  id: string;
  code: string;
  name: string;
  credits: number;
  instructor: string;
  department: string;
  description: string;
  capacity: number;
  enrolled: number;
  schedule: {
    day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
    startTime: string;
    endTime: string;
    location: string;
  }[];
};

export type Enrollment = {
  id: string;
  studentId: string;
  courseId: string;
  enrollmentDate: string;
  grade?: string;
  status: 'Active' | 'Completed' | 'Withdrawn';
};

export type Announcement = {
  id: string;
  title: string;
  content: string;
  date: string;
  author: string;
  important: boolean;
};

export type Department = {
  id: string;
  name: string;
  head: string;
  description: string;
};