import React from 'react';
import { Users, BookOpen, GraduationCap, Award, TrendingUp, Calendar } from 'lucide-react';
import { Card, CardContent } from './ui/Card';
import { students, courses, enrollments } from '../data/mockData';
import StudentList from './StudentList';
import CourseList from './CourseList';
import AnnouncementList from './AnnouncementList';

const Dashboard: React.FC = () => {
  // Calculate stats
  const totalStudents = students.length;
  const totalCourses = courses.length;
  const activeEnrollments = enrollments.filter(e => e.status === 'Active').length;
  const avgGpa = students.reduce((sum, student) => sum + student.gpa, 0) / totalStudents;
  
  const stats = [
    { name: 'Total Students', value: totalStudents, icon: <Users className="h-6 w-6 text-indigo-600" /> },
    { name: 'Total Courses', value: totalCourses, icon: <BookOpen className="h-6 w-6 text-amber-500" /> },
    { name: 'Active Enrollments', value: activeEnrollments, icon: <GraduationCap className="h-6 w-6 text-green-600" /> },
    { name: 'Average GPA', value: avgGpa.toFixed(2), icon: <Award className="h-6 w-6 text-blue-600" /> },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.name} className="overflow-hidden border-slate-200">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">{stat.icon}</div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-slate-500 truncate">{stat.name}</dt>
                    <dd>
                      <div className="text-lg font-medium text-slate-900">{stat.value}</div>
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <Card className="overflow-hidden shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-slate-900 flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-indigo-600" />
                  Enrollment Trends
                </h3>
                <div className="inline-flex space-x-2">
                  <button className="px-2 py-1 text-xs font-medium rounded bg-slate-100 text-slate-600 hover:bg-slate-200">1M</button>
                  <button className="px-2 py-1 text-xs font-medium rounded bg-indigo-600 text-white">6M</button>
                  <button className="px-2 py-1 text-xs font-medium rounded bg-slate-100 text-slate-600 hover:bg-slate-200">1Y</button>
                </div>
              </div>
              <div className="h-[200px] flex items-end">
                {/* Simple bar chart visualization */}
                {[65, 45, 75, 60, 80, 90].map((height, i) => (
                  <div key={i} className="group relative flex-1 mr-1 last:mr-0">
                    <div 
                      className="absolute bottom-0 inset-x-0 rounded-t w-full bg-indigo-200 group-hover:bg-indigo-300 transition-colors"
                      style={{ height: `${height}%` }}
                    >
                      <div className="invisible group-hover:visible absolute -top-8 left-1/2 transform -translate-x-1/2 px-2 py-1 rounded bg-slate-800 text-white text-xs whitespace-nowrap">
                        {height}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-2 text-xs text-slate-500">
                <div>Jul</div>
                <div>Aug</div>
                <div>Sep</div>
                <div>Oct</div>
                <div>Nov</div>
                <div>Dec</div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="overflow-hidden shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-slate-900 flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-indigo-600" />
                  Upcoming Events
                </h3>
                <button className="text-sm text-indigo-600 hover:text-indigo-800">View All</button>
              </div>
              <div className="space-y-3">
                {[
                  { title: 'Faculty Meeting', date: 'Oct 15, 2025', time: '9:00 AM', location: 'Conference Room A' },
                  { title: 'Midterm Exams', date: 'Oct 20-24, 2025', time: 'All Day', location: 'Various Classrooms' },
                  { title: 'Career Fair', date: 'Nov 5, 2025', time: '10:00 AM - 4:00 PM', location: 'Grand Hall' },
                  { title: 'Guest Lecture: Digital Transformation', date: 'Nov 12, 2025', time: '2:00 PM', location: 'Auditorium 1' }
                ].map((event, i) => (
                  <div key={i} className="flex items-start p-3 hover:bg-slate-50 rounded-lg transition-colors">
                    <div className="w-12 h-12 flex-shrink-0 rounded-md bg-indigo-100 text-indigo-700 flex flex-col items-center justify-center text-xs font-medium">
                      <span>{event.date.split(',')[0].split(' ')[0]}</span>
                      <span className="text-lg">{event.date.split(',')[0].split(' ')[1]}</span>
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-slate-900">{event.title}</p>
                      <p className="text-xs text-slate-500 mt-1">{event.time} • {event.location}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <AnnouncementList />
      </div>
      
      <StudentList />
      
      <CourseList />
    </div>
  );
};

export default Dashboard;