import React from 'react';

interface AvatarProps {
  src?: string;
  alt?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  fallback?: string;
}

const Avatar: React.FC<AvatarProps> = ({
  src,
  alt = 'Avatar',
  size = 'md',
  className = '',
  fallback,
}) => {
  const sizeClasses = {
    xs: 'h-6 w-6 text-xs',
    sm: 'h-8 w-8 text-sm',
    md: 'h-10 w-10 text-base',
    lg: 'h-12 w-12 text-lg',
    xl: 'h-16 w-16 text-xl',
  };

  const [imgError, setImgError] = React.useState(!src);

  const handleError = () => {
    setImgError(true);
  };

  // Get initials from the alt text or fallback
  const getInitials = () => {
    const text = fallback || alt;
    return text
      .split(' ')
      .map(part => part[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  return (
    <div className={`relative inline-block ${sizeClasses[size]} ${className}`}>
      {!imgError && src ? (
        <img
          src={src}
          alt={alt}
          onError={handleError}
          className="rounded-full object-cover w-full h-full"
        />
      ) : (
        <div className="flex items-center justify-center w-full h-full rounded-full bg-slate-200 text-slate-600 font-medium">
          {getInitials()}
        </div>
      )}
    </div>
  );
};

export default Avatar;