import React, { useState } from 'react';
import { Menu, Bell, Search, BookOpen, X } from 'lucide-react';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar';

interface NavbarProps {
  toggleSidebar: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ toggleSidebar }) => {
  const [showSearch, setShowSearch] = useState(false);

  return (
    <nav className="bg-white border-b border-slate-200 fixed w-full z-10">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <button 
              onClick={toggleSidebar}
              className="inline-flex items-center justify-center p-2 rounded-md text-slate-700 hover:text-slate-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500 lg:hidden"
            >
              <Menu size={24} />
            </button>
            <div className="flex-shrink-0 flex items-center ml-0 lg:ml-0">
              <BookOpen className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-slate-800 hidden md:block">L1 INFO ANCIENS SYSTEME</span>
            </div>
          </div>

          <div className="hidden md:flex md:flex-1 md:items-center md:justify-center px-2 lg:ml-6 lg:justify-end">
            <div className="max-w-lg w-full">
              <label htmlFor="search" className="sr-only">Rechercher</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-slate-400" />
                </div>
                <input
                  id="search"
                  name="search"
                  className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-md leading-5 bg-white placeholder-slate-500 focus:outline-none focus:placeholder-slate-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Rechercher étudiants, cours..."
                  type="search"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center md:hidden">
            <button 
              onClick={() => setShowSearch(!showSearch)}
              className="p-2 rounded-md text-slate-700 hover:text-slate-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
            >
              {showSearch ? <X size={24} /> : <Search size={24} />}
            </button>
          </div>

          <div className="flex items-center">
            <button className="p-2 rounded-md text-slate-700 hover:text-slate-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500 relative">
              <Bell size={20} />
              <span className="absolute top-1 right-1 block h-2 w-2 rounded-full bg-red-500"></span>
            </button>
            <div className="ml-3 relative">
              <div>
                <Button variant="ghost" className="flex items-center max-w-xs rounded-full">
                  <Avatar size="sm" src="https://images.pexels.com/photos/3796217/pexels-photo-3796217.jpeg" alt="Aimee Kanza" />
                  <span className="ml-2 text-sm font-medium text-slate-700 hidden lg:block">Aimee Kanza</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showSearch && (
        <div className="px-2 pt-2 pb-3 md:hidden">
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-slate-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-slate-300 rounded-md leading-5 bg-white placeholder-slate-500 focus:outline-none focus:placeholder-slate-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              placeholder="Rechercher étudiants, cours..."
            />
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;