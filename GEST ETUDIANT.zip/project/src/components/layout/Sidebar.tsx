import React from 'react';
import { Users, BookOpen, GraduationCap, CalendarDays, BellRing, BarChart3, Settings, Home } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
}

interface NavItem {
  name: string;
  href: string;
  icon: React.ReactNode;
  current: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  const navigation: NavItem[] = [
    { name: 'Tableau de bord', href: '/', icon: <Home size={20} />, current: true },
    { name: 'Étudiants', href: '/students', icon: <Users size={20} />, current: false },
    { name: 'Cours', href: '/courses', icon: <BookOpen size={20} />, current: false },
    { name: 'Notes', href: '/grades', icon: <GraduationCap size={20} />, current: false },
    { name: 'Calendrier', href: '/calendar', icon: <CalendarDays size={20} />, current: false },
    { name: 'Annonces', href: '/announcements', icon: <BellRing size={20} />, current: false },
    { name: 'Rapports', href: '/reports', icon: <BarChart3 size={20} />, current: false },
    { name: 'Paramètres', href: '/settings', icon: <Settings size={20} />, current: false },
  ];

  return (
    <div className={`fixed inset-y-0 left-0 z-20 w-64 transform bg-slate-800 transition duration-200 ease-in-out lg:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex h-full flex-col">
        <div className="flex h-16 shrink-0 items-center border-b border-slate-700 px-6">
          <div className="flex items-center">
            <BookOpen className="h-8 w-8 text-amber-500" />
            <span className="ml-2 text-xl font-semibold text-white">L1 INFO</span>
          </div>
        </div>
        <div className="flex flex-1 flex-col overflow-y-auto pt-5 pb-4">
          <nav className="mt-5 flex-1 space-y-1 px-3">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`group flex items-center rounded-md px-3 py-2 text-sm font-medium ${
                  item.current
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
                aria-current={item.current ? 'page' : undefined}
              >
                <span className="mr-3 text-slate-400 group-hover:text-slate-300">{item.icon}</span>
                {item.name}
              </a>
            ))}
          </nav>
        </div>
        <div className="shrink-0 border-t border-slate-700 p-4">
          <div className="flex items-center">
            <div>
              <p className="text-sm font-medium text-white">Année Académique</p>
              <p className="text-xs text-slate-400">2025-2026</p>
            </div>
            <div className="ml-auto">
              <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-amber-500">
                <span className="text-xs font-medium leading-none text-white">1</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;