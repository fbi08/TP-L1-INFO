import React, { useState } from 'react';
import { Search, Filter, ChevronDown, ChevronRight } from 'lucide-react';
import { courses } from '../data/mockData';
import { Card, CardHeader, CardContent } from './ui/Card';
import Button from './ui/Button';
import Badge from './ui/Badge';

const CourseList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('');

  // Filter courses based on search term and filters
  const filteredCourses = courses.filter(course => {
    const matchesSearch = searchTerm === '' || 
      course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = selectedDepartment === '' || course.department === selectedDepartment;
    
    return matchesSearch && matchesDepartment;
  });

  // Get unique departments for filters
  const departments = Array.from(new Set(courses.map(c => c.department)));

  // Determine enrollment status color
  const getEnrollmentStatusColor = (enrolled: number, capacity: number) => {
    const ratio = enrolled / capacity;
    if (ratio >= 0.9) return 'danger';
    if (ratio >= 0.7) return 'warning';
    return 'success';
  };

  return (
    <Card className="shadow-sm">
      <CardHeader className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <h2 className="text-xl font-bold text-slate-800">Course Catalog</h2>
        <div className="flex flex-col space-y-2 sm:flex-row sm:space-x-2 sm:space-y-0">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="Search courses..."
              className="pl-10 pr-4 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="relative group">
            <Button 
              variant="outline" 
              className="w-full sm:w-auto flex items-center"
              icon={<Filter size={16} />}
            >
              Filter
              <ChevronDown size={16} className="ml-1" />
            </Button>
            
            <div className="hidden group-hover:block absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
              <div className="px-3 py-2">
                <span className="text-xs font-medium text-slate-500">Department</span>
                <div className="mt-1 space-y-1">
                  <div className="flex items-center">
                    <input
                      id="all-departments"
                      type="radio"
                      name="department"
                      className="h-4 w-4 border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      checked={selectedDepartment === ''}
                      onChange={() => setSelectedDepartment('')}
                    />
                    <label htmlFor="all-departments" className="ml-2 text-sm text-slate-700">All</label>
                  </div>
                  {departments.map(dept => (
                    <div key={dept} className="flex items-center">
                      <input
                        id={`dept-${dept}`}
                        type="radio"
                        name="department"
                        className="h-4 w-4 border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        checked={selectedDepartment === dept}
                        onChange={() => setSelectedDepartment(dept)}
                      />
                      <label htmlFor={`dept-${dept}`} className="ml-2 text-sm text-slate-700">{dept}</label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <Button 
            variant="primary"
            className="w-full sm:w-auto"
          >
            Add Course
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="px-0">
        <div className="overflow-x-auto">
          <table className="w-full min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Course
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Department
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Instructor
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Enrollment
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Schedule
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {filteredCourses.map((course) => (
                <tr key={course.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-slate-900">{course.name}</div>
                    <div className="text-sm text-slate-500">{course.code} • {course.credits} credits</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-900">{course.department}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-900">{course.instructor}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Badge 
                        variant={getEnrollmentStatusColor(course.enrolled, course.capacity)}
                      >
                        {course.enrolled}/{course.capacity}
                      </Badge>
                      <div className="ml-2 w-16 h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${
                            getEnrollmentStatusColor(course.enrolled, course.capacity) === 'danger' 
                              ? 'bg-red-500' 
                              : getEnrollmentStatusColor(course.enrolled, course.capacity) === 'warning'
                                ? 'bg-orange-500'
                                : 'bg-green-500'
                          }`}
                          style={{ width: `${(course.enrolled / course.capacity) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-slate-500 space-y-1">
                      {course.schedule.map((schedule, index) => (
                        <div key={index}>
                          {schedule.day}: {schedule.startTime}-{schedule.endTime}
                          <span className="text-xs ml-1 text-slate-400">({schedule.location})</span>
                        </div>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                    <Button variant="ghost" size="sm" icon={<ChevronRight size={16} />}>
                      Details
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {filteredCourses.length === 0 && (
            <div className="text-center py-10">
              <p className="text-sm text-slate-500">No courses match your search criteria.</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CourseList;