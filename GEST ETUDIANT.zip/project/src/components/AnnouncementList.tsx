import React from 'react';
import { BellRing, AlertCircle, Calendar, User } from 'lucide-react';
import { announcements } from '../data/mockData';
import { Card, CardHeader, CardContent } from './ui/Card';
import Button from './ui/Button';
import Badge from './ui/Badge';

const AnnouncementList: React.FC = () => {
  // Format date to a more readable format
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <Card className="shadow-sm">
      <CardHeader className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div className="flex items-center">
          <BellRing className="h-5 w-5 text-indigo-600 mr-2" />
          <h2 className="text-xl font-bold text-slate-800">Announcements</h2>
        </div>
        <Button variant="primary">New Announcement</Button>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {announcements.map((announcement) => (
            <div 
              key={announcement.id}
              className={`p-4 rounded-lg border ${
                announcement.important ? 'border-amber-200 bg-amber-50' : 'border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start">
                  {announcement.important && (
                    <AlertCircle className="h-5 w-5 text-amber-500 mr-2 mt-0.5 flex-shrink-0" />
                  )}
                  <div>
                    <h3 className="text-lg font-medium text-slate-900 flex items-center">
                      {announcement.title}
                      {announcement.important && (
                        <Badge variant="secondary" className="ml-2">Important</Badge>
                      )}
                    </h3>
                    <p className="mt-1 text-sm text-slate-600 whitespace-pre-line">{announcement.content}</p>
                    <div className="mt-2 flex flex-wrap items-center text-xs text-slate-500 space-x-4">
                      <div className="flex items-center">
                        <Calendar className="h-3.5 w-3.5 mr-1" />
                        <span>{formatDate(announcement.date)}</span>
                      </div>
                      <div className="flex items-center">
                        <User className="h-3.5 w-3.5 mr-1" />
                        <span>{announcement.author}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex-shrink-0 self-start">
                  <Button variant="ghost" size="sm">Edit</Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default AnnouncementList;