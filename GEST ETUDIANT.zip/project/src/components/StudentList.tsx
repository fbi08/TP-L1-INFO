import React, { useState } from 'react';
import { Search, Filter, Download, ChevronDown, ChevronRight } from 'lucide-react';
import { Student } from '../types';
import { students } from '../data/mockData';
import { Card, CardHeader, CardContent } from './ui/Card';
import Button from './ui/Button';
import Badge from './ui/Badge';
import Avatar from './ui/Avatar';

const StudentList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('');
  const [selectedLevel, setSelectedLevel] = useState<string>('');

  // Filter students based on search term and filters
  const filteredStudents = students.filter(student => {
    const matchesSearch = searchTerm === '' || 
      student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = selectedDepartment === '' || student.department === selectedDepartment;
    const matchesLevel = selectedLevel === '' || student.level === selectedLevel;
    
    return matchesSearch && matchesDepartment && matchesLevel;
  });

  // Get unique departments and levels for filters
  const departments = Array.from(new Set(students.map(s => s.department)));
  const levels = Array.from(new Set(students.map(s => s.level)));

  return (
    <Card className="shadow-sm">
      <CardHeader className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <h2 className="text-xl font-bold text-slate-800">Student Directory</h2>
        <div className="flex flex-col space-y-2 sm:flex-row sm:space-x-2 sm:space-y-0">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="Search students..."
              className="pl-10 pr-4 py-2 border border-slate-300 rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="relative group">
            <Button 
              variant="outline" 
              className="w-full sm:w-auto flex items-center"
              icon={<Filter size={16} />}
            >
              Filter
              <ChevronDown size={16} className="ml-1" />
            </Button>
            
            <div className="hidden group-hover:block absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
              <div className="px-3 py-2 border-b">
                <span className="text-xs font-medium text-slate-500">Department</span>
                <div className="mt-1 space-y-1">
                  <div className="flex items-center">
                    <input
                      id="all-departments"
                      type="radio"
                      name="department"
                      className="h-4 w-4 border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      checked={selectedDepartment === ''}
                      onChange={() => setSelectedDepartment('')}
                    />
                    <label htmlFor="all-departments" className="ml-2 text-sm text-slate-700">All</label>
                  </div>
                  {departments.map(dept => (
                    <div key={dept} className="flex items-center">
                      <input
                        id={`dept-${dept}`}
                        type="radio"
                        name="department"
                        className="h-4 w-4 border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        checked={selectedDepartment === dept}
                        onChange={() => setSelectedDepartment(dept)}
                      />
                      <label htmlFor={`dept-${dept}`} className="ml-2 text-sm text-slate-700">{dept}</label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="px-3 py-2">
                <span className="text-xs font-medium text-slate-500">Level</span>
                <div className="mt-1 space-y-1">
                  <div className="flex items-center">
                    <input
                      id="all-levels"
                      type="radio"
                      name="level"
                      className="h-4 w-4 border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      checked={selectedLevel === ''}
                      onChange={() => setSelectedLevel('')}
                    />
                    <label htmlFor="all-levels" className="ml-2 text-sm text-slate-700">All</label>
                  </div>
                  {levels.map(level => (
                    <div key={level} className="flex items-center">
                      <input
                        id={`level-${level}`}
                        type="radio"
                        name="level"
                        className="h-4 w-4 border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        checked={selectedLevel === level}
                        onChange={() => setSelectedLevel(level)}
                      />
                      <label htmlFor={`level-${level}`} className="ml-2 text-sm text-slate-700">{level}</label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            className="w-full sm:w-auto"
            icon={<Download size={16} />}
          >
            Export
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="px-0">
        <div className="overflow-x-auto">
          <table className="w-full min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Student
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  ID
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Department
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Level
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  GPA
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {filteredStudents.map((student) => (
                <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Avatar src={student.profileImage} alt={`${student.firstName} ${student.lastName}`} size="sm" />
                      <div className="ml-4">
                        <div className="text-sm font-medium text-slate-900">{student.firstName} {student.lastName}</div>
                        <div className="text-sm text-slate-500">{student.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-900">{student.studentId}</div>
                    <div className="text-sm text-slate-500">Enrolled: {new Date(student.enrollmentDate).toLocaleDateString()}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-900">{student.department}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Badge 
                      variant={
                        student.level === 'Undergraduate' ? 'info' : 
                        student.level === 'Graduate' ? 'primary' : 
                        'secondary'
                      }
                    >
                      {student.level}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-medium ${
                      student.gpa >= 3.7 ? 'text-green-700' : 
                      student.gpa >= 3.0 ? 'text-amber-700' : 
                      'text-slate-700'
                    }`}>
                      {student.gpa.toFixed(1)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                    <Button variant="ghost" size="sm" icon={<ChevronRight size={16} />}>
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {filteredStudents.length === 0 && (
            <div className="text-center py-10">
              <p className="text-sm text-slate-500">No students match your search criteria.</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default StudentList;