import { Student, Course, Enrollment, Announcement, Department } from '../types';

// Données des étudiants
export const students: Student[] = [
  {
    id: '1',
    firstName: 'Aimee',
    lastName: 'Kanza Musenga',
    email: 'aimee.kanza@univ-l1info.cd',
    studentId: 'L1INFO2025001',
    enrollmentDate: '2025-09-01',
    department: 'Informatique',
    level: 'Undergraduate',
    gpa: 3.8,
    profileImage: 'https://images.pexels.com/photos/3796217/pexels-photo-3796217.jpeg',
    address: '123 Avenue de l\'Université, Kinshasa',
    phoneNumber: '+243 123 456 789',
  },
  {
    id: '2',
    firstName: 'Jean',
    lastName: 'Mukendi',
    email: 'jean.mukendi@univ-l1info.cd',
    studentId: 'L1INFO2025002',
    enrollmentDate: '2025-09-01',
    department: 'Informatique',
    level: 'Undergraduate',
    gpa: 3.7,
    profileImage: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg',
    address: '456 Rue de la Science, Kinshasa',
    phoneNumber: '+243 987 654 321',
  }
];

// Données des cours
export const courses: Course[] = [
  {
    id: '1',
    code: 'INFO101',
    name: 'Introduction à la Programmation',
    credits: 4,
    instructor: 'Dr. Kabongo',
    department: 'Informatique',
    description: 'Concepts fondamentaux de la programmation et algorithmes de base.',
    capacity: 30,
    enrolled: 28,
    schedule: [
      { day: 'Monday', startTime: '09:00', endTime: '11:00', location: 'Salle 101' },
      { day: 'Thursday', startTime: '14:00', endTime: '16:00', location: 'Salle 101' },
    ],
  },
  {
    id: '2',
    code: 'INFO102',
    name: 'Structures de Données',
    credits: 4,
    instructor: 'Prof. Mutombo',
    department: 'Informatique',
    description: 'Étude des structures de données fondamentales et leurs applications.',
    capacity: 25,
    enrolled: 23,
    schedule: [
      { day: 'Tuesday', startTime: '10:00', endTime: '12:00', location: 'Salle 102' },
      { day: 'Friday', startTime: '13:00', endTime: '15:00', location: 'Salle 102' },
    ],
  }
];

// Données des inscriptions
export const enrollments: Enrollment[] = [
  { id: '1', studentId: '1', courseId: '1', enrollmentDate: '2025-09-01', grade: 'A', status: 'Active' },
  { id: '2', studentId: '1', courseId: '2', enrollmentDate: '2025-09-01', grade: 'A-', status: 'Active' }
];

// Données des annonces
export const announcements: Announcement[] = [
  {
    id: '1',
    title: 'Bienvenue au Semestre d\'Automne 2025',
    content: 'Chers étudiants, nous sommes ravis de commencer cette nouvelle année académique. Tous les services du campus sont maintenant ouverts.',
    date: '2025-09-01',
    author: 'Directeur des Études',
    important: true,
  },
  {
    id: '2',
    title: 'Session d\'Orientation - 15 Septembre',
    content: 'Une session d\'orientation obligatoire aura lieu le 15 septembre dans l\'amphithéâtre principal.',
    date: '2025-09-05',
    author: 'Service Pédagogique',
    important: true,
  }
];

// Données des départements
export const departments: Department[] = [
  {
    id: '1',
    name: 'Informatique',
    head: 'Prof. Kalala',
    description: 'Formation en sciences informatiques et technologies de l\'information.',
  }
];